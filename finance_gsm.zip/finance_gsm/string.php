<?php
$for_qa_approval="QA Approve";
$for_ae_approval="AE Approve";
$for_qa_page="For QA Approval";
$for_ae_page="For AE Approval";
$request_release="Request Release";
$request_release_btn="Request Cash Release";
$request_release_text="For Cash Release";
$qa_text="For QA Approval";
$qa_approve_btn="Approve By QA";
$ae_approve_btn="Approve by Account Executive";
$ae_text="For Account Executive Approval";
?>