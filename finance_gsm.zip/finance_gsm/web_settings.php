<?php 
include'page_header.php';
?>
<link rel="stylesheet" href="css/colorpicker.css" type="text/css" />
    <link rel="stylesheet" media="screen" type="text/css" href="css/layout.css" />
	<!--<script type="text/javascript" src="js/jquery.js"></script>-->
	<script type="text/javascript" src="js/colorpicker.js"></script>
    <script type="text/javascript" src="js/eye.js"></script>
    <script type="text/javascript" src="js/utils.js"></script>
    <script type="text/javascript" src="js/layout.js?ver=1.0.2"></script>
			<p>
					<div id="colorSelector"><div style="background-color: #0000ff"></div></div>
				</p>
	