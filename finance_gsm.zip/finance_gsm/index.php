<script>window.location.assign('login.php')</script>
